chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installed');
});


console.log("background.js");